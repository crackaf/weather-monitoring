#ifndef _ESP8266_HARDWARE_SERIAL_H_
#define _ESP8266_HARDWARE_SERIAL_H_

#include "ESP8266_common.h"

#endif